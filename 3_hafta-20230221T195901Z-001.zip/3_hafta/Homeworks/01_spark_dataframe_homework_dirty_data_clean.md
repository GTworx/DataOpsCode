## Question  

- Use this dataset: ` https://github.com/erkansirin78/datasets/raw/master/dirty_store_transactions.csv ` 
do the following tasks:

### 1. 
Clean data

### 2. 
Write clean data to hive  `test1.clean_transactions`, format should be orc.

### 3. 
Write clean data to Postgresql `traindb.public.clean_transactions`. 

### 4. 
Write clean data to hdfs `/user/train/spark_odev_transaction` in parquet format.
