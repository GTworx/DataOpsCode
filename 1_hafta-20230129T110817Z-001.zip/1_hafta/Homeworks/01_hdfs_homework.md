### Q-1: 
- Download and put `https://raw.githubusercontent.com/erkansirin78/datasets/master/Wine.csv` dataset in hdfs `/user/train/hdfs_odev` directory.

### Q-2:
- Copy this hdfs file `/user/train/hdfs_odev/Wine.csv` to `/tmp/hdfs_odev` hdfs directory.

### Q-3:
- Delete `/tmp/hdfs_odev` directory with skipping the trash. 

### Q-4:
-  Explore `/user/train/hdfs_odev/Wine.csv` file from web hdfs.  