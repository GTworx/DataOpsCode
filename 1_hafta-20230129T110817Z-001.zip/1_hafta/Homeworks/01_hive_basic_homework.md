# Questions

### Q-1: 
- Create a hive database `hive_odev` and load this data https://raw.githubusercontent.com/erkansirin78/datasets/master/Wine.csv into `wine` table.

### Q-2
- In `wine` table filter records that `Alcohol`greater than 13.00 then insert these records into `wine_alc_gt_13` table.

### Q-3
- Drop `hive_odev` database including underlying tables in a single command.

### Q-4 
- Load this https://raw.githubusercontent.com/erkansirin78/datasets/master/hive/employee.txt into table `employee` in `company` database. 

### Q-5
- Write a query that returns the employees whose Python skill is greater than 70.