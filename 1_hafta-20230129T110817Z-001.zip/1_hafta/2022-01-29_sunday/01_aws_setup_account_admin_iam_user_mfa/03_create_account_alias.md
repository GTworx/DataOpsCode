# Create Account Alias

- It is difficult to remember Account ID. Usually we create an alias for this id and use it for login url.

## 1. Create alias

![](images/17_create_account_alias.png)

------------------------

![](images/18_preferred_alias.png)

----------------------

## 2. Login with alias

### 2.1. Copy alias console url

![](images/19_copy_alias_console_url.png)

-----------------------

### 2.2. Open different browser
- For example edge or firefox
- Paste copied alias url

![](images/20_alias_login_page.png)

-------------------------
